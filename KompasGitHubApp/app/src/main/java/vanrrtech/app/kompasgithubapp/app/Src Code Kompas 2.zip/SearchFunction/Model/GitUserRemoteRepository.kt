package vanrrtech.app.kompasgithubapp.app.SearchFunction.Model

import android.util.Log
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import vanrrtech.app.kompasgithubapp.app.UserDetailFunction.Model.UserRepoDetails

class GitUserRemoteRepository {

    companion object{
        val BASE_URL = "https://api.github.com/"
        val ITEM_DELAY = 300L

        var mRemoteRepo : GitUserRemoteRepository? = null

        fun getUserRemoteRepo(): GitUserRemoteRepository {
            if(mRemoteRepo == null){
                mRemoteRepo = GitUserRemoteRepository()
            }

            return mRemoteRepo!!

        }
    }
    var logging =  HttpLoggingInterceptor()
        .setLevel(HttpLoggingInterceptor.Level.BODY);
    var mClient = OkHttpClient.Builder().addInterceptor(logging)
    private val userService = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .client(mClient.build())
        .build()
        .create(GitUserService::class.java)

    fun getRecentUsers() : Flow<UserItem?> {

        return flow {
            var userSource : List<UserItem?>? = userService.getUsersList()

            userSource?.forEach {
                emit(it)
                kotlinx.coroutines.delay(ITEM_DELAY)
            }
        }
    }

    fun getSearchedUser(name: String) : Flow<UserItem?> {
        Log.i("Log", "name")

        return flow {
            //q=user%3AwingSan1262&type=Users
            var response = userService.searchUser(name, "Users")
            Log.i("us", "response total ${response?.total}, response item ${response?.items.toString()}")
            response?.items?.forEach {
                emit(it)
                kotlinx.coroutines.delay(ITEM_DELAY)
            }
        }
    }

    fun getUserRepoDetail(userName: String) : Flow<UserRepoDetails?> {
        Log.i("Log", "name")

        return flow {
            //q=user%3AwingSan1262&type=Users
            var response = userService.getUserRepos(userName)
            response.forEach {
                emit(it)
                kotlinx.coroutines.delay(ITEM_DELAY)
            }
        }
    }

}