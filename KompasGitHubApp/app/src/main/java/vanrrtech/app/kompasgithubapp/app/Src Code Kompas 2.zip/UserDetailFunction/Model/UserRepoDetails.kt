package vanrrtech.app.kompasgithubapp.app.UserDetailFunction.Model

data class UserRepoDetails(
    var name : String,
    var description : String,
    var watcher_count : Int,
    var update_at : String
)
